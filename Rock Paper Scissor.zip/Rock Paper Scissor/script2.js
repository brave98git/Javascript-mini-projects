//Optimized Code
const choices = ["rock", "paper", "scissors"];
const playerDisplay = document.getElementById("playerDisplay");
const computerDisplay = document.getElementById("computerDisplay");
const resultDisplay = document.getElementById("resultDisplay");
const playerScoreDisplay = document.getElementById("playerScoreDisplay");
const computerScoreDisplay = document.getElementById("computerScoreDisplay");

let playerScore = 0;
let computerScore = 0;

const winConditions = {
    rock: "scissors",
    paper: "rock",
    scissors: "paper"
};

function playGame(playerChoice) {
    const computerChoice = choices[Math.floor(Math.random() * choices.length)];

    let result = "IT'S A TIE!";
    let resultClass = "tieText";

    if (playerChoice !== computerChoice) {
        const isPlayerWinner = winConditions[playerChoice] === computerChoice;
        if (isPlayerWinner) {
            result = "YOU WIN";
            resultClass = "greenText";
            playerScore++;
            playerScoreDisplay.textContent = playerScore;
        } else {
            result = "YOU LOST";
            resultClass = "redText";
            computerScore++;
            computerScoreDisplay.textContent = computerScore;
        }
    }

    playerDisplay.textContent = `PLAYER: ${playerChoice.toUpperCase()}`;
    computerDisplay.textContent = `COMPUTER: ${computerChoice.toUpperCase()}`;
    resultDisplay.textContent = result;

    // Animate result
    resultDisplay.className = resultClass + " result-animate";

    // Remove animation class after it finishes (so it can be re-added next time)
    setTimeout(() => {
        resultDisplay.classList.remove("result-animate");
    }, 500);
}

